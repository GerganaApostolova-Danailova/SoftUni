﻿using System;

namespace _02Zoo
{
    public class StartUp
    {
        static void Main()
        {
            Console.WriteLine("Hello World!");
        }
    }
}
