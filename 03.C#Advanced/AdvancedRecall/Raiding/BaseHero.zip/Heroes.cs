﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Raiding
{
    public enum Heroes
    {
        Druid = 1,
        Paladin = 2,
        Rogue = 3,
        Warrior= 4
    }
}
