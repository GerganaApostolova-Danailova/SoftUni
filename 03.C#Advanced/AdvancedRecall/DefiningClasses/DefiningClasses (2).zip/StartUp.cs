﻿using System;

namespace DefiningClasses
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            //Person firstPerson = new Person();
            //firstPerson.Name = "Peter";
            //firstPerson.Age = 20;
            //Person secondPerson = new Person();
            //secondPerson.Name = "George";
            //secondPerson.Age = 18;

            //Person thirtdPerson = new Person();
            //thirtdPerson.Name = "Jose";
            //thirtdPerson.Age = 43;

        }
    }
}
