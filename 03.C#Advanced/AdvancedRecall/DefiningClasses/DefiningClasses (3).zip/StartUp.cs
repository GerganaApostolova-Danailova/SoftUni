﻿using System;
using System.Collections.Generic;

namespace DefiningClasses
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            int numofPeople = int.Parse(Console.ReadLine());

            Family family = new Family();

            for (int i = 0; i < numofPeople; i++)
            {
                string[] command = Console.ReadLine()
                    .Split(" ", StringSplitOptions.RemoveEmptyEntries);

                string name = command[0];
                int age = int.Parse(command[1]);

                Person person = new Person(name,age);

                family.AddMember(person);

            }
                Console.WriteLine(family.GetOldestMember());
        }
    }
}
