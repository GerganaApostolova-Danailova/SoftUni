﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Telephony
{
    public interface ICalling
    {
        void GetCall(string phoneNumbers);
    }
}

