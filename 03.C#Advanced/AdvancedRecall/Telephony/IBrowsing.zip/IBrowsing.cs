﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Telephony
{
    public interface IBrowsing
    {
        void GetBrowse(string webSides);
    }
}
