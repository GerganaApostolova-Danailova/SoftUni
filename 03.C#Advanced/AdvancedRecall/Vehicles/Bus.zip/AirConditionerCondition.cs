﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vehicles
{
    public enum AirConditionerCondition
    {
        Off,
        On
    }
}
