﻿using System;

namespace CarManufacturer
{
    class Program
    {
        static void Main(string[] args)
        {
            var car = new StartUp();

            car.Make = "Toyota";
            car.Model = "Yaris";
            car.Year = 2006;

            Console.WriteLine($"Make: {car.Make}\nModel: {car.Model}\nYear: {car.Year}");
        }
    }
}
