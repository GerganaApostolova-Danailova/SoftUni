﻿namespace CarManufacturer
{
    internal class Car
    {
        public Car()
        {
        }
    }
}