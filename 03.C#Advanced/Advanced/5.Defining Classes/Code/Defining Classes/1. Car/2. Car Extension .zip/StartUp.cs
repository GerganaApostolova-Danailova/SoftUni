﻿using System;

namespace CarManufacturer
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            var car = new Car();

            car.Make = "Toyota";
            car.Model = "Yaris";
            car.Year = 2006;
            car.FuelQuantity = 12;
            car.FuelConsumption = 80;
            car.Drive(200);
            car.Drive(500);

            Console.WriteLine(car.WhoAmI());
        }
    }
}
