﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace P02_CarsSalesman
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Output output = new Output();

            output.Run();
        }
    }

}
