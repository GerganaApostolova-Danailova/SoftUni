﻿using System;

namespace VehiclesExtension
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            string[] input = Console.ReadLine().Split();
            Vehicle car = new Car(double.Parse(input[1]), double.Parse(input[2]), double.Parse(input[3]));
            input = Console.ReadLine().Split();
            Vehicle truck = new Truck(double.Parse(input[1]), double.Parse(input[2]), double.Parse(input[3]));
            input = Console.ReadLine().Split();
            Vehicle bus = new Bus(double.Parse(input[1]), double.Parse(input[2]), double.Parse(input[3]));

            int count = int.Parse(Console.ReadLine());

            for (int i = 0; i < count; i++)
            {
                input = Console.ReadLine().Split();

                string type = input[1];
                string command = input[0];
                double value = double.Parse(input[2]);

                switch (type)
                {
                    case nameof(Car):
                        ExecuteCommand(car, command, value);
                        break;
                    case nameof(Truck):
                        ExecuteCommand(truck, command, value);
                        break;
                    case nameof(Bus):
                        ExecuteCommand(bus, command, value);
                        break;
                }
            }

            Console.WriteLine(car);
            Console.WriteLine(truck);
            Console.WriteLine(bus);
        }

        private static void ExecuteCommand(Vehicle vehicle, string command, double value)
        {
            switch (command)
            {
                case "Drive":
                    Console.WriteLine(vehicle.Drive(value));
                    break;
                case "Refuel":
                    try
                    {
                        vehicle.Refuel(value);
                    }
                    catch (ArgumentException ex)
                    {
                        Console.WriteLine(ex.Message);
                    }
                    break;
                case "DriveEmpty":
                    ((Bus)vehicle).SwitchOffAirConditioner();
                    Console.WriteLine(vehicle.Drive(value));
                    ((Bus)vehicle).SwitchOnAirConditioner();
                    break;
            }
        }
        //string[] carInput = Console.ReadLine()
        //   .Split();

        //string[] truckInput = Console.ReadLine()
        //    .Split();

        //double CarFuelCuantity = double.Parse(carInput[1]);
        //double CarFuelConsumption = double.Parse(carInput[2]);

        //Vehicle car = new Car(CarFuelCuantity, CarFuelConsumption);

        //double TruckFuelCuantity = double.Parse(truckInput[1]);
        //double TruckFuelConsumption = double.Parse(truckInput[2]);

        //Vehicle truck = new Truck(TruckFuelCuantity, TruckFuelConsumption);

        //int num = int.Parse(Console.ReadLine());

        //for (int i = 0; i < num; i++)
        //{
        //    string[] drivingCurrentVehicle = Console.ReadLine()
        //        .Split();

        //    string move = drivingCurrentVehicle[0];
        //    string vehicle = drivingCurrentVehicle[1];

        //    if (move == "Drive")
        //    {
        //        double distance = double.Parse(drivingCurrentVehicle[2]);

        //        if (vehicle == "Car")
        //        {
        //            Console.WriteLine(car.Drive(distance));
        //        }
        //        else if (vehicle == "Truck")
        //        {
        //            Console.WriteLine(truck.Drive(distance));
        //        }
        //    }
        //    else if (move == "Refuel")
        //    {
        //        double fuel = double.Parse(drivingCurrentVehicle[2]);

        //        if (vehicle == "Car")
        //        {
        //            car.Refuel(fuel);
        //        }
        //        else if (vehicle == "Truck")
        //        {
        //            truck.Refuel(fuel);
        //        }
        //    }
        //}

        //Console.WriteLine(car);
        //Console.WriteLine(truck);
    }
}

