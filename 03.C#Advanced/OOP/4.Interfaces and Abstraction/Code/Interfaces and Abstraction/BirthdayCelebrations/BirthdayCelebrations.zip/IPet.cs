﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BirthdayCelebrations
{
    public interface IPet
    {
        string Name { get; }

        string Birthday { get; }
    }
}
