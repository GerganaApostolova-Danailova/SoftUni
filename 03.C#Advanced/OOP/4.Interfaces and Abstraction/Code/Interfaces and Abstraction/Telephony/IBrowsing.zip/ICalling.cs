﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PersonInfo
{
    public interface ICalling
    {
        //string Number { get; set; }

        string GetCalling(string namber);
    }
}
