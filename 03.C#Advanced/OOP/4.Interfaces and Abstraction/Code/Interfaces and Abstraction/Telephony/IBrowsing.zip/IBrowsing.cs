﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PersonInfo
{
    public interface IBrowsing
    {
        //string WebSite { get; set; }

        string GetBrowse(string webSite);
    }
}
