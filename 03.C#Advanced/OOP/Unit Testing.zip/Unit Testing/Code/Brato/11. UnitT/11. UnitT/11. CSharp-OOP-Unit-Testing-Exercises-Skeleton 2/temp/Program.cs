﻿using System;

namespace temp
{
    class Program
    {
        static void Main(string[] args)
        {
            var arr = new int[] { 1, 2, 3 };

            
        }
    }
}
