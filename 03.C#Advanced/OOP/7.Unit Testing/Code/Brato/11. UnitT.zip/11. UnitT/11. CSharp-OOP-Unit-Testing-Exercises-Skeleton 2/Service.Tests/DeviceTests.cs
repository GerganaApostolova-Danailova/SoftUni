﻿using NUnit.Framework;

namespace Service.Tests
{
    public class DeviceTests
    {
        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public void Test1()
        {
            Assert.Pass();
        }
    }
}
