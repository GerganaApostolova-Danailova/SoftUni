﻿using System;

namespace PetStore.Common
{
    public static class DbConfig
    {
        public static string DefConnString = @"Server=TCECO\WINCC;Database=PetStore;Integrated Security=True;";
    }
}
