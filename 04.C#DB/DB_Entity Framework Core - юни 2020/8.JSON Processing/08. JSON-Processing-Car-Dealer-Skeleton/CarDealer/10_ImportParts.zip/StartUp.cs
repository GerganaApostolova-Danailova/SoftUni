﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using AutoMapper;
using CarDealer.Data;
using CarDealer.Models;
using Newtonsoft.Json;

namespace CarDealer
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            CarDealerContext db = new CarDealerContext();

            //ResetDatabase(db);

            ////Problem 09

            //string inputJson = File.ReadAllText("../../../Datasets/suppliers.json");

            //string result = ImportSuppliers(db, inputJson);

            //Console.WriteLine(result);

            //Problem 10

            string inputJson = File.ReadAllText("../../../Datasets/parts.json");

            string result = ImportSuppliers(db, inputJson);

            Console.WriteLine(result);
        }
        private static void ResetDatabase(CarDealerContext db)
        {
            db.Database.EnsureDeleted();
            Console.WriteLine("DB is deteted");
            db.Database.EnsureCreated();
            Console.WriteLine("DB is created");
        }


        //Problem 09
        public static string ImportSuppliers(CarDealerContext context, string inputJson)
        {
            Supplier[] suppliers = JsonConvert.DeserializeObject<Supplier[]>(inputJson);

            context.Suppliers.AddRange(suppliers);
            context.SaveChanges();

            return $"Successfully imported {suppliers.Length}.";
        }

        //Problem 10

        public static string ImportParts(CarDealerContext context, string inputJson)
        {
            var suppllierCount = context.Suppliers.Count();

            var parts = JsonConvert.DeserializeObject<List<Part>>(inputJson).Where(x => x.SupplierId <= suppllierCount);

            context.Parts.AddRange(parts);
            context.SaveChanges();

            return $"Successfully imported {parts.Count()}.";


        }


    }
}