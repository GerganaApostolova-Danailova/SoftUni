﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using AutoMapper;
using CarDealer.Data;
using CarDealer.DTO;
using CarDealer.Models;
using Newtonsoft.Json;

namespace CarDealer
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            CarDealerContext db = new CarDealerContext();

            //ResetDatabase(db);

            ////Problem 09

            //string inputJson = File.ReadAllText("../../../Datasets/suppliers.json");

            //string result = ImportSuppliers(db, inputJson);

            //Console.WriteLine(result);

            ////Problem 10

            //string inputJson = File.ReadAllText("../../../Datasets/parts.json");

            //string result = ImportParts(db, inputJson);

            //Console.WriteLine(result);

            ////Problem 11

            //string inputJson = File.ReadAllText("../../../Datasets/cars.json");

            //string result = ImportCars(db, inputJson);

            //Console.WriteLine(result);

            ////Problem 12

            //string inputJson = File.ReadAllText("../../../Datasets/customers.json");

            //string result = ImportCustomers(db, inputJson);

            //Console.WriteLine(result);

            //Problem 13

            string inputJson = File.ReadAllText("../../../Datasets/sales.json");

            string result = ImportSales(db, inputJson);

            Console.WriteLine(result);

        }
        private static void ResetDatabase(CarDealerContext db)
        {
            db.Database.EnsureDeleted();
            Console.WriteLine("DB is deteted");
            db.Database.EnsureCreated();
            Console.WriteLine("DB is created");
        }


        //Problem 09
        public static string ImportSuppliers(CarDealerContext context, string inputJson)
        {
            Supplier[] suppliers = JsonConvert.DeserializeObject<Supplier[]>(inputJson);

            context.Suppliers.AddRange(suppliers);
            context.SaveChanges();

            return $"Successfully imported {suppliers.Length}.";
        }

        //Problem 10

        public static string ImportParts(CarDealerContext context, string inputJson)
        {
            var suppllierCount = context.Suppliers.Count();

            var parts = JsonConvert.DeserializeObject<List<Part>>(inputJson).Where(x => x.SupplierId <= suppllierCount);

            context.Parts.AddRange(parts);
            context.SaveChanges();

            return $"Successfully imported {parts.Count()}.";
        }

        //Problem 11

        public static string ImportCars(CarDealerContext context, string inputJson)
        {
            var carsDto = JsonConvert.DeserializeObject<List<CarDTO>>(inputJson);
            var cars = new List<Car>();
            var carParts = new List<PartCar>();

            foreach (var carDto in carsDto)
            {

                var newCar = new Car()
                {
                    Make = carDto.Make,
                    Model = carDto.Model,
                    TravelledDistance = carDto.TravelledDistance,

                };
                cars.Add(newCar);

                foreach (var carPartId in carDto.PartsId.Distinct())
                {
                    var newCarPart = new PartCar()
                    {
                        PartId = carPartId,
                        Car = newCar
                    };
                    carParts.Add(newCarPart);
                }

            }
            context.Cars.AddRange(cars);
            context.PartCars.AddRange(carParts);
            context.SaveChanges();

            return $"Successfully imported { cars.Count()}.";
        }

        //Problem 12

        public static string ImportCustomers(CarDealerContext context, string inputJson)
        {
            Customer[] customers = JsonConvert
                .DeserializeObject<Customer[]>(inputJson);

            context.Customers.AddRange(customers);
            context.SaveChanges();

            return $"Successfully imported {customers.Length}.";
        }

        //Problem 13

        public static string ImportSales(CarDealerContext context, string inputJson)
        {
            Sale[] sales = JsonConvert
               .DeserializeObject<Sale[]>(inputJson);

            context.Sales.AddRange(sales);
            context.SaveChanges();

            return $"Successfully imported {sales.Length}.";
        }


    }
}