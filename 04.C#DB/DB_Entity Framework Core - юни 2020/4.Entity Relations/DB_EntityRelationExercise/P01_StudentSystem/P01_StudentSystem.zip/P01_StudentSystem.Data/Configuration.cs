﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P01_StudentSystem.Data
{
    internal static class Configuration
    {
        internal static string ConnectionString = @"Server=TCECO\WINCC;Database=StudentSystem;Integrated Security=true;";
    }
}
