﻿namespace P01_StudentSystem.Data.Models.Enumeration
{
    public enum ContentType
    {
        //can be Application, Pdf or Zip

        Application = 1,
        Pdf = 2,
        Zip = 3
    }
}
