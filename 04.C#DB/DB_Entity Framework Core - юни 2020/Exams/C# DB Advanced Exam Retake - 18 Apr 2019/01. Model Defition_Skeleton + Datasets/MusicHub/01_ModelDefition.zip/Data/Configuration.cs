﻿namespace MusicHub.Data
{
   public static class Configuration
    {
        public static string ConnectionString =
            @"Server=TCECO\WINCC;Database=MusicHub;Trusted_Connection=True";
    }
}
