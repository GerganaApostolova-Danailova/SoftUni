﻿namespace BookShop.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=TCECO\WINCC;Database=BookShop;Trusted_Connection=True";
    }
}