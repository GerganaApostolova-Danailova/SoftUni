﻿namespace Cinema.Data
{
    using Cinema.Data.Models;
    using Microsoft.EntityFrameworkCore;

    public class CinemaContext : DbContext
    {
        public CinemaContext() { }

        public CinemaContext(DbContextOptions options)
            : base(options) { }

        public DbSet<Customer> Customers;

        public DbSet<Hall> Halls;

        public DbSet<Movie> Movies;

        public DbSet<Projection> Projections;

        public DbSet<Seat> Seats;

        public DbSet<Ticket> Tickets;

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder
                    .UseSqlServer(Configuration.ConnectionString);
            }
        }

    }
}