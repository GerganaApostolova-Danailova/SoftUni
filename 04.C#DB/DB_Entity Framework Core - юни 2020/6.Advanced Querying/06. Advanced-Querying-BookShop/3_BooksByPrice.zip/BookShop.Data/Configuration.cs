﻿namespace BookShop.Data
{
    internal class Configuration
    {
        internal static string ConnectionString 
            => @"Server=TCECO\WINCC;Database=BookShop;Integrated Security=True;";
    }
}
