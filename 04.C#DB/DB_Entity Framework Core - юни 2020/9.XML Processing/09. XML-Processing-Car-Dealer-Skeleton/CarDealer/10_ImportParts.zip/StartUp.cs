﻿using CarDealer.Data;
using System;
using CarDealer.NewFolder;
using System.Xml.Serialization;
using System.Xml;
using CarDealer.XMLHelper;
using CarDealer.NewFolder.Import;
using System.Linq;
using CarDealer.Models;
using System.IO;

namespace CarDealer
{
    public class StartUp
    {
        //private static string ResultDirectoryPath = "../../../Datasets/Results";

        public static void Main(string[] args)
        {
            CarDealerContext db = new CarDealerContext();

            //ResetDatabase(db);

            ////Problem 09

            //var usersXml = File.ReadAllText("../../../Datasets/suppliers.xml");
            //var result = ImportSuppliers(db, usersXml);

            //Problem 10

            var usersXml = File.ReadAllText("../../../Datasets/parts.xml");
            var result = ImportParts(db, usersXml);

            //string xml = GetUsersWithProducts(db);

            //EnsureDirectoryExists(ResultDirectoryPath);

            //File.WriteAllText(ResultDirectoryPath + "/users-and-products.xml", xml);


        }
        private static void ResetDatabase(CarDealerContext db)
        {
            db.Database.EnsureDeleted();
            Console.WriteLine("DB is deteted");
            db.Database.EnsureCreated();
            Console.WriteLine("DB is created");
        }

        //private static void EnsureDirectoryExists(string path)
        //{
        //    if (!Directory.Exists(path))
        //    {
        //        Directory.CreateDirectory(path);
        //    }
        //}

        //Problem 09

        public static string ImportSuppliers(CarDealerContext context, string inputXml)
        {
            var resultSuppliers = XmlConverter.Deserializer<ImportSuppliersDto>(inputXml, "Suppliers");

            var suppliers = resultSuppliers
                .Select(s => new Supplier
                {
                    Name = s.Name,
                    IsImporter = s.IsImporter
                })
                .ToArray();

            context.Suppliers.AddRange(suppliers);
            context.SaveChanges();

            return $"Successfully imported {suppliers.Length}";
        }

        //Problem 10

        public static string ImportParts(CarDealerContext context, string inputXml)
        {
            var resultParts = XmlConverter
                .Deserializer<ImportPartsDto>(inputXml, "Parts");

            var correctId = context
                .Suppliers
                .ToArray()
                .Count();

            var parts = resultParts
                .Where(p => p.SupplierId <= correctId)
                .Select(p => new Part
                {
                    Name = p.Name,
                    Price = p.Price,
                    Quantity = p.Quantity,
                    SupplierId = p.SupplierId
                })
                .ToList();

            context.Parts.AddRange(parts);
            context.SaveChanges();

            return $"Successfully imported {parts.Count}";
        }


    }
}