﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VaporStore.Data.Models.Enums
{
    public enum CardType
    {
        Debit = 1,
        Credit = 2
    }
}
