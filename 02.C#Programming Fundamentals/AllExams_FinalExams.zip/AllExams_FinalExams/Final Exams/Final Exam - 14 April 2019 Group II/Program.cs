﻿using System;

namespace Final_Exam___14_April_2019_Group_II
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
